حساب من - پروژه اندروید (Android Studio)

این بسته سورس پروژه اندروید است و APK آماده نیست.

روش ساخت APK:
1) Android Studio را نصب کنید.
2) پوشه hesabeman_android را با گزینه Open باز کنید.
3) صبر کنید Gradle Sync تمام شود و Android SDK Platform 35 نصب باشد.
4) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را انتخاب کنید.

برنامه داخل WebView اجرا می‌شود و داده‌های محلی در فضای ذخیره‌سازی مرورگر WebView باقی می‌مانند.
اتصال خودکار Google Drive در این سورس هنوز اضافه نشده است. برای آن باید OAuth Client ID معتبر از Google Cloud Console ساخته و پیکربندی شود. رمز عبور حساب گوگل را به هیچ‌کس ندهید.

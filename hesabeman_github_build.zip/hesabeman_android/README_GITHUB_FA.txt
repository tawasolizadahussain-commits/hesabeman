راهنمای ساخت APK با GitHub Actions

1) محتویات این پوشه را در ریشه یک GitHub repository بارگذاری کنید (فایل ZIP را در خود GitHub به عنوان سورس پروژه نگه ندارید؛ ابتدا Extract کنید و فایل‌ها و پوشه‌ها را بارگذاری کنید).
2) در مخزن GitHub وارد تب Actions شوید.
3) در صورت درخواست، گزینه I understand my workflows, go ahead and enable them را انتخاب کنید.
4) از فهرست سمت چپ Build Hesabeman APK را انتخاب کنید.
5) روی Run workflow و سپس دکمه سبز Run workflow بزنید.
6) پس از سبز شدن اجرای workflow، همان اجرا را باز کنید و از بخش Artifacts فایل hesabeman-debug-apk را دانلود کنید.
7) ZIP دانلودشده را باز کنید؛ فایل app-debug.apk داخل آن است.

این یک APK آزمایشی (debug) است. Google Drive backup هنوز در سورس پیاده‌سازی نشده است.
